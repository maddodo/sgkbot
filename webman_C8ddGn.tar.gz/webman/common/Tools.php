<?php
namespace common;

class Tools {
    public static function randStr(int $length): string {
        $s = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890";
        $tmp = "";
        for ($a = 0; $a <= $length; $a++){
            $tmp .= $s[mt_rand(0, mb_strlen($s)-1)];
        }
        return $tmp;
    }
}