<?php
namespace app\controller;

use soxft\OpenIdSdk;
use support\Db;
use support\Request;
use support\Response;
use common\Tools;

class Index
{
    public function index(Request $request)
    {
        //return redirect('https://9420.ltd/api/v1/login?appid=20220707507034&redirect_uri=http://test.com/ok');
        $search = $request->get("qq", "");
        $users = Db::table('8eqq')->where("username",'=', "$search")
        //->limit(20)
        //->offset(20)
            ->get();
        //$users = Db::table('id')->select(["content"])->where("id", $search)->first();
        //$t = time();
        return new Response(200,[
            "Content-Type" => "application/text; charset=utf-8"
        ], $users);
        // return json([
        //     "method" => 'get',
        //     "id" => $users,
        //     "time" => date("Y年m月d日 H时i分s秒", $t),
        // ]);
        //return $users;
    }
    public function num(Request $request)
    {
        $search = $request->get("num", "");
        $users = Db::table('8eqq')->where("mobile",'=', "$search")->get();
        return new Response(200,[
            "Content-Type" => "application/text; charset=utf-8"
        ], $users);
    }
    public function name(Request $request)
    {
        $search = $request->get("name", "");
        $users = Db::table('id')->where("姓名",'=', "$search")->get();
        return new Response(200,[
            "Content-Type" => "application/text; charset=utf-8"
        ], $users);
    }
    public function phone(Request $request)
    {
        $search = $request->get("phone", "");
        $users = Db::table('id')->where("手机号 ",'=', "$search")->get();
        return new Response(200,[
            "Content-Type" => "application/text; charset=utf-8"
        ], $users);
    }
    public function lol(Request $request)
    {
        $search = $request->get("uin", "");
        $users = Db::table('lol_bind')->where("uin",'=', "$search")->get();
        return new Response(200,[
            "Content-Type" => "application/text; charset=utf-8"
        ], $users);
    }
    public function bili(Request $request)
    {
        $search = $request->get("uid", "");
        $users = Db::table('bili')->where("uid",'=', "$search")->get();
        return new Response(200,[
            "Content-Type" => "application/text; charset=utf-8"
        ], $users);
    }
    public function weibo(Request $request)
    {
        $search = $request->get("uid", "");
        $users = Db::table('wb1')->where("uid",'=', "$search")->get();
        return new Response(200,[
            "Content-Type" => "application/text; charset=utf-8"
        ], $users);
    }
    public function weibop(Request $request)
    {
        $search = $request->get("p", "");
        $users = Db::table('wb1')->where("phone",'=', "$search")->get();
        return new Response(200,[
            "Content-Type" => "application/text; charset=utf-8"
        ], $users);
    }
    /**++++
     * 插入参数
     *
     * @param support\Request $request
     * @return Response
     */
    public function insert(Request $request): Response
    {

        $content = $request->post("content","default");
        $time = time();

        try {
            $id = Db::table('test')->insertGetId(
                ['content' => $content, 'time' => $time]
            );
        } catch (\Throwable $err) {
            return new Response(403, [], "用户名已存在！");
        }


        return json([
            "xltz" => 'post',
            "c" => $content,
            "id" => $id,
            "rand" => Tools::randStr(10),
            "time" => date("Y年m月d日 H时i分s秒", $time)
        ])->withStatus(200);
    }
    public function token(Request $request)
    {
        $token = $request->get("token");
        $xopenid = new OpenIdSdk('20220707507034', '76d7751957a71e5a.59f7a3a0dff4acbe.VFjYJEePSaidXejN.ciWyWZofblCbixyg');
        $res = $xopenid->getUserInfo($token); //如果token正确 该方法会返回用户信息
        print_r($res); //输出用户信息
        $success = $res["success"];
        if ($success) {
            $uniqueId = $res['data']['uniqueId'];
        };
        return $uniqueId;
    }
}
