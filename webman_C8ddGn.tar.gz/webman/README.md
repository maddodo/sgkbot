# webman

High performance HTTP Service Framework for PHP based on [Workerman](https://github.com/walkor/workerman).

# Manual

https://www.workerman.net/doc/webman

# Benchmarks

https://www.techempower.com/benchmarks/#section=test&runid=9716e3cd-9e53-433c-b6c5-d2c48c9593c1&hw=ph&test=db&l=zg24n3-1r&a=2
![image](https://user-images.githubusercontent.com/6073368/96447814-120fc980-1245-11eb-938d-6ea408716c72.png)

## LICENSE

MIT
